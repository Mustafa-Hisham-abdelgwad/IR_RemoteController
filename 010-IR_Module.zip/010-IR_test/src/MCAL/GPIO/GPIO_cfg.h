/*
 * GPIO_cfg.h
 *
 *  Created on: Aug 18, 2022
 *      Author: mazen
 */

#ifndef MCAL_GPIO_GPIO_CFG_H_
#define MCAL_GPIO_GPIO_CFG_H_





#endif /* MCAL_GPIO_GPIO_CFG_H_ */
