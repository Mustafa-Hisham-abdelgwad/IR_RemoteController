

#include "LIB/STD_TYPES.h"
#include "MCAL/RCC/RCC_int.h"
#include "MCAL/GPIO/GPIO_int.h"
#include "MCAL/STK/STK_int.h"
#include "MCAL/EXTI/EXTI_int.h"
#include "MCAL/NVIC/NVIC_int.h"

u8 G_u8StartFlag = 0;
u32 FrameData[50];
u32 EdgeCounter = 0 ;
u8 IR_Data = 0;


MGPIO_Config_t ir_pin = {
GPIO_PORTA, GPIO_PIN0, GPIO_MODE_INPUT, GPIO_SPEED_LOW, GPIO_OTYPE_PUSHPULL, GPIO_INPUT_NO_PULL
};

MGPIO_Config_t rgb_pins[3] = {
{GPIO_PORTA, GPIO_PIN1, GPIO_MODE_INPUT, GPIO_SPEED_LOW, GPIO_OTYPE_PUSHPULL},
{GPIO_PORTA, GPIO_PIN2, GPIO_MODE_INPUT, GPIO_SPEED_LOW, GPIO_OTYPE_PUSHPULL},
{GPIO_PORTA, GPIO_PIN3, GPIO_MODE_INPUT, GPIO_SPEED_LOW, GPIO_OTYPE_PUSHPULL}
};


void ParseFrame(void)
{
	for(int i=0; i<8 ; i++)
	{
		if(FrameData[17+i] >= 2000 && FrameData[17+i] <=2500 )
		{
			SET_BIT(IR_Data, i) ;
		}
		else
		{
			CLR_BIT(IR_Data. i);
		}
	}
	G_u8StartFlag = 0 ;
	EdgeCounter = 0;
	RGB();
}

void RGB(void)
{
	switch(IR_Data)
	{
	case 70:
		MGPIO_vSetPinVal(rgb_pins[RED].Port,rgb_pins[RED].Pin, GPIO_HIGH );
		break;
	case 80:
		MGPIO_vSetPinVal(rgb_pins[GREEN].Port,rgb_pins[GREEN].Pin, GPIO_HIGH );
		break;
	}
}



void GetFrame(void)
{
	if(G_u8StartFlag == 0)
	{
		MSTK_vSetInterval_single(1000000,ParseFrame);
		G_u8StartFlag = 1 ;
	}
	else
	{
		FrameData[EdgeCounter] = MSTK_vGetElapsedTime();
		MSTK_vSetInterval_single(1000000,ParseFrame);
		EdgeCounter++ ;
	}

}



int main(void)
{
	MRCC_vInit();
	MRCC_vEnableClock(RCC_AHB1, RCC_EN_GPIOA);
	MRCC_vEnableClock(RCC_APB2, RCC_EN_SYSCFG );




	MGPIO_vInit(&ir_pin);

	for(u8 i=0; i<3; i++)
	{
		MGPIO_vInit(&rgb_pins[i]);
	}


	MEXTI_vSetCallback(EXTI_LINE0, GetFrame);
	MEXTI_vEnableLine(EXTI_FALLING, EXTI_LINE0);

	NVIC_vInit();
	NVIC_vEnableInterrupt(NVIC_EN_EXTI0) ;

	MSTK_vInit();

	while(1)
	{

	}
}
